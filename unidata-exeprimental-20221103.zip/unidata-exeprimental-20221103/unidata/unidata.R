#Set working directory to unidata
setwd("D:/work_folders/unidatap/unidata")

# load libraries and functions
suppressWarnings(source("_/_/__unidatap.R"))

#search for indicators
searchunidatapindicator('en','rice', TRUE)

#search for countries or regions
unidataapifindcr('en','burkina', TRUE, '')

#Get indicators
unidatapgetdata(c("BFA"),c("Production in tonnes for Rice paddy"), 'y', c('-1'), 1980,2022, FALSE, '')

