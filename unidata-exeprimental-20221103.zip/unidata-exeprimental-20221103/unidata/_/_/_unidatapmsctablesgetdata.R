#unidatapmsctablesgetdata.R
unidatapmsctablesgetdata <<- function(countrypartnerlist, indicatorlist, startperiod, endperiod){
msctablesindicatorsentrypoint <- read.csv("msctablesindicatorsentrypoint.csv")
msctablesindicatorsentrypoint
msctableslist <- list()
typeof(msctableslist)
for (i in indicatorlist){
    #print(i)
    data1x <- msctablesindicatorsentrypoint %>% filter(indicator==i,(!(indicator=="(test)")))
    #print(data1x)
    #print(nrow(data1x))
    if (nrow(data1x)>0){
        for (mappingt in unique(as.list(data1x$countryregmappingtable))){
            #print(mappingt)
            rnew=TRUE
            for (rec in msctableslist) {
                #print("##")
                #print(rec)
                #print(i)
                if (rec==mappingt){
                    rnew=FALSE
                }
            }
            #print (rnew)
            if (rnew){
                rec = mappingt
                #print("$$")
                msctableslist[[(length(msctableslist) + 1)]] <- rec
            }
        }
    }
}
#print(msctableslist)
msctablelinks<-list()
for (tbln in msctableslist){
    #print(tbln)
    tbl<-read.csv(paste(tbln,".csv",sep=""))
    #print(tbl)
    tbl1<-tbl %>% filter(indicator %in% indicatorlist, countrypartner %in% countrypartnerlist)
    #print(tbl1)
    for (link in unique(as.list(tbl1$msctablelink))){
        #print("...")
        #print(link)
        msctablelinks[length(msctablelinks)+1]=link
    }
}
#print(msctablelinks)
mydatatoreturn0 <- emptyunidatadataframe()
for (llink in (unique(msctablelinks))){
    #print(llink)
    datatable<-read_sheet(llink,"msctabledata")
    #print(datatable)
    datatable1<-datatable %>% filter(indicatorcode %in% indicatorlist, countryregioncode %in% countrypartnerlist, timeperiod>=startperiod,timeperiod<=endperiod)
    #print(datatable1)
    mydatatoreturn0 <- rbind(mydatatoreturn0,datatable1)
}
return(mydatatoreturn0)
}