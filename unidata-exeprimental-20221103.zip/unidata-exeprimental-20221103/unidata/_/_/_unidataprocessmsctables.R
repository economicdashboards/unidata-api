unidataprocessmsctable <<- function(msctablelink, msctablename)
{
    msctablesindicatorsentrypoint<-read.csv("msctablesindicatorsentrypoint.csv")
    tablelink=msctablelink
    #print(tablelink)
    tablename=msctablename
    # print(tablename)
    sdata<-read_sheet(tablelink,"msctabledata")
    #print(sdata)
    #print(unique(sdata$indicatorcode))
    for (ind in unique(sdata$indicatorcode)){
        #print(ind)
        sdata1<-sdata %>% filter(indicatorcode==ind)
        #print(sdata1)
        if (nrow(sdata1)>0){
           for (ccd in unique(sdata1$countryregioncode )){
               #print(ccd)
               sdata2<-sdata1 %>% filter(countryregioncode==ccd)
               ccdmappingtablename=paste(str_trim(str_split(ccd,"/")[1]),"_imapping",sep="")
               #print(ccdmappingtablename)
               mt<-msctablesindicatorsentrypoint %>% filter(indicator==ind,countryregmappingtable==ccdmappingtablename)
               #print(mt)
               #print(nrow(mt))
               if (nrow(mt)==0){
                   msctablesindicatorsentrypoint[nrow(msctablesindicatorsentrypoint)+1,]=c(ind,ccdmappingtablename)
               }
               if ((file.exists(paste(ccdmappingtablename,".csv",sep="")))){
                   mfile<-read.csv(paste(ccdmappingtablename,".csv",sep=""))
               }
               else
               {
                   mfile <- data.frame(indicator=character(),
                                       countrypartner=character(),
                                       msctablelink=character(),
                                       periodicity=character(),
                                       beginperiod=character(),
                                       endperiod=character())
               }
               #print(mfile)
               prdcity=max(sdata2$periodicity)
               #print(prdcity)
               minp=min(sdata2$timeperiod)
               #print(minp)
               maxp=max(sdata2$timeperiod)
               #print(maxp)
               mfilefiltered<-mfile %>% filter(indicator==ind,countrypartner==ccd,msctablelink==tablelink)
               #print(mfilefiltered)
               #print(nrow(mfilefiltered))
               if (nrow(mfilefiltered)==0){
                   mfile[nrow(mfile)+1,]=c(ind,ccd,tablelink,prdcity,minp,maxp)
                   write.csv(mfile,paste(ccdmappingtablename,".csv",sep=""),row.names = FALSE)
               }
           }
        }
    }
    write.csv(msctablesindicatorsentrypoint,"msctablesindicatorsentrypoint.csv",row.names = FALSE)
}

unidataprocessmsctables <<- function(){
nnow<-function(){
        return (as.POSIXct(Sys.time(), format = '%Y-%m-%d T %H:%M:%S'))
}
undatapcentral="https://docs.google.com/spreadsheets/d/1MHiOL_fsasbWenHOyWg8080JW88VWeyHFOj3L-hErrc/edit?usp=sharing"
msctablesondisc <<- read.csv("msctables.csv")
msctablesondisc$msctablestatus <- "(unactive)"
msctablesondisc<<-subset(msctablesondisc, !(msctablelink=="(test)"))
#print(msctablesondisc)
msctablesonline<<-subset(msctablesonline, !(msctablelink=="(test)"))
msctablesonline<<-read_sheet(undatapcentral,"msctables")
#print(msctablesonline)
for (i in 1:nrow(msctablesonline)){
    #print (i)
    tablelink=msctablesonline$msctablelink[i]
    #print(tablelink)
    tablename=msctablesonline$msctablename[i]
    #print(tablename)
    tableversion=msctablesonline$msctableversion[i]
    #print(tableversion)
    #print(colnames(msctablesondisc))
    if (!(tablelink=="(test)")) {
    rondisc <- msctablesondisc %>% filter(msctablelink==tablelink)
    #print("-----")
    #print(rondisc)
    #print(nrow(rondisc))
    vmsctablelink=tablelink
    vmsctablename=tablename
    vmsctableversion=tableversion
    vmsctablestatus="active"
    vmsctabledatecreated=nnow()
    vmsctabledateprocessed=nnow()
    if (nrow(rondisc)>0) {
       tableoldversion=as.numeric(min(rondisc$msctableversion))
       if (tableversion>tableoldversion)
       {
           #print("process updated table")
           unidataprocessmsctable(tablelink, tablename)
           msctablesondisc$msctablename[msctablesondisc$msctablelink==vmsctablelink] <- vmsctablename
           msctablesondisc$msctableversion[msctablesondisc$msctablelink==vmsctablelink] <- vmsctableversion
           msctablesondisc$msctablestatus[msctablesondisc$msctablelink==vmsctablelink] <- vmsctablestatus
           msctablesondisc$msctabledateprocessed[msctablesondisc$msctablelink==vmsctablelink] <- vmsctabledateprocessed
       }
       else
       {
           #print("update just table fields")
           #print(msctablesondisc)
           msctablesondisc$msctablename[msctablesondisc$msctablelink==vmsctablelink] <- vmsctablename
           msctablesondisc$msctablestatus[msctablesondisc$msctablelink==vmsctablelink] <- vmsctablestatus
       }
    }
    else
    {
        #print("process new table")
        unidataprocessmsctable(tablelink, tablename)
        msctablesondisc[nrow(msctablesondisc)+1,] <- c(vmsctablelink, vmsctablename, vmsctableversion, vmsctablestatus, vmsctabledatecreated, vmsctabledateprocessed)
    }
    }
}
write.csv(msctablesondisc,"msctables.csv",row.names=FALSE)
}