# unidataphelperfunctions.R
#Add package if not already added and load
addpackages <<- function(packages) {
package.check <- lapply(
  packages,
  FUN = function(x) {
    if (!require(x, character.only = TRUE)) {
      install.packages(x, dependencies = TRUE)
      library(x, character.only = TRUE)
    }
  }
)
    #return (package.check)
}

addpackages(c("googlesheets4","tidyverse"))
gs4_deauth()
options(googlesheets4_quiet = TRUE)

emptyunidatadataframe <<- function() {   
    emptyunidatadf <- data.frame(countryregioncode=character(),
                 countryregionname=character(),
                 indicatorcode=character(),
                 indicatorname=character(),
                 periodicity=character(),
                 timeperiod=character(),
                 datavalue=character(),
                 datavaluecode=character(),
                 datavaluelabel=character(),
                 sourcecode=character(),
                 sourcename=character(),
                 sourceconsulteddate=character(),
                 sourcelastupdateddate=character(),
                 mainlink=character(),
                 otherlinks=character(),
                 flag=character(),
                 notes=character())
    return (emptyunidatadf)
}

unidatarecode000 <<- function(listcode, slink, regionname, codesfield, valuesfield) {
    r <- list()
    xdata <- read_sheet(slink, regionname)
    #print("data")
    #print(slink)
    #print(xdata)
    #xdata0 <- read_sheet(slink, regionname)
    #print(xdata0)
    for (v in listcode) {
        if (length(str_trim(v)) > 0 ) {
            xdata1 <- xdata %>% filter(.data[[codesfield]]==str_trim(v))
            #print(xdata1)
            r <- append(r,(xdata1[[valuesfield]][1]))
        }
        else
        {
            r <- append(r,"")
        }
    }
    return (r)
}

unidatarecodedimension_00 <<- function(listcode, slink, sheetname, codesfield, valuesfield, ordersfield, ordervalue) {
    r <- list()
    xdata <- read_sheet(slink, sheetname)
    #print("data")
    #print(slink)
    #print(xdata)
    for (v in listcode) {
        #print ("V...")
        #print(v)
        if (length(str_trim(v)) > 0 ) {
            vv=""
            n=0
            vlist <- unlist(strsplit(v,"/"))
            #print("split")
            #print(vlist)
            nn= -1
            for (v0 in vlist) {
                #print("...")
                #print(str_trim(v0))
                nn=nn+1
                vv1<-str_trim(v0)
                if (length(str_trim(v)) > 0 ) {
                    xdata1 <- xdata %>% filter(.data[[codesfield]]==str_trim(vv1), grepl(paste("/",toString(nn),"/",sep=" "),.data[[ordersfield]]))
                    #print(xdata1)
                    vx=str_trim(xdata1[[valuesfield]][1])
                    if (is.null(vx)) {
                        vx=""
                    }
                    #print(vx)
                    n=n+1
                    if (n==1) {
                        vv=vx
                    }
                    else
                    {
                        vv <- paste(vv,"/",vx, sep=" ")
                    }
                }
                else
                {
                    vx  = ""
                    n=n+1
                    if (n==1) {
                        vv=vx
                    }
                    else
                    {
                        vv <- paste(vv,"/",vx, sep=" ")
                    }
                }
                #print("vv=========")
                #print(vv)
            }
            r <- append(r,vv)
        }
        else
        {
            r <- append(r,"")
        }
    }
    return (r)
}

undatapcentral="https://docs.google.com/spreadsheets/d/1MHiOL_fsasbWenHOyWg8080JW88VWeyHFOj3L-hErrc/edit?usp=sharing"
unidatarecodedimension <- function(listcodes, apiname, fieldno) {
    r <- list()
    if (length(str_trim(apiname)) > 0 ) {
        slink=unidatarecode000 (c(apiname), undatapcentral, "unidataprecodecentral", "apicode", paste("v", toString(fieldno), sep = "", collapse = NULL))[[1]]
        #print("Slink:")
        #print(slink)
        if (length(str_trim(slink)) > 0){
            r <- unidatarecodedimension_00(listcodes, slink, paste("v", toString(fieldno),sep=""), "codefield","valuefield","orders", fieldno)
        }
    }
    return (r)
}