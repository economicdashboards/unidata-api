# unidataphelperfunctions.R

# This function adds a package if it was not already added and loads it
addpackages <<- function(packages) {
package.check <- lapply(
  packages,
  FUN = function(x) {
    if (!require(x, character.only = TRUE)) {
      install.packages(x, dependencies = TRUE)
      library(x, character.only = TRUE)
    }
  }
)
}

# Adds packages for connection to Google sheets
addpackages(c("googlesheets4","tidyverse"))
gs4_deauth()
options(googlesheets4_quiet = TRUE)

# Creates the template for the data taht will be returned
emptyunidatadataframe <<- function() {   
    emptyunidatadf <- data.frame(countryregioncode=character(),
                 countryregionname=character(),
                 indicatorcode=character(),
                 indicatorname=character(),
                 periodicity=character(),
                 timeperiod=character(),
                 datavalue=character(),
                 datavaluecode=character(),
                 datavaluelabel=character(),
                 sourcecode=character(),
                 sourcename=character(),
                 sourceconsulteddate=character(),
                 sourcelastupdateddate=character(),
                 mainlink=character(),
                 otherlinks=character(),
                 flag=character(),
                 notes=character(),
                 api=character(),
                 additionalfields=character()
                 )
    return (emptyunidatadf)
}

# Charactesr mapping function (used to map indicators to specific folders)
charmap_uni <<- function(x) {
  y = 0
  x<-tolower(x)
  if (x=='0') {y=1}
  if (x=='1') {y=2}
  if (x=='2') {y=3}
  if (x=='3') {y=4}
  if (x=='4') {y=5}
  if (x=='5') {y=6}
  if (x=='6') {y=7}
  if (x=='7') {y=8}
  if (x=='8') {y=9}
  if (x=='9') {y=10}
  if (x=='a') {y=11}
  if (x=='b') {y=12}
  if (x=='c') {y=13}
  if (x=='d') {y=14}
  if (x=='e') {y=15}
  if (x=='f') {y=16}
  if (x=='g') {y=17}
  if (x=='h') {y=18}
  if (x=='i') {y=19}
  if (x=='j') {y=20}
  if (x=='k') {y=21}
  if (x=='l') {y=22}
  if (x=='m') {y=23}
  if (x=='n') {y=24}
  if (x=='o') {y=25}
  if (x=='p') {y=26}
  if (x=='q') {y=27}
  if (x=='r') {y=28}
  if (x=='s') {y=29}
  if (x=='t') {y=30}
  if (x=='u') {y=31}
  if (x=='v') {y=32}
  if (x=='w') {y=33}
  if (x=='x') {y=34}
  if (x=='y') {y=35}
  if (x=='z') {y=36}
  return (y)
}

# Function that maps indicators to specific folders
unidataindicatorcsvfolder <<- function(s){
  v = 0
  for (i in 1:nchar(s)){
    v0<-charmap_uni(substr(s,i,i))
    if (v0>0){
      v = v + 5*v0 + 4
    }
  }
  v = v %% 250
  x = paste("000", as.character(v), sep="")
  return (paste("r",substr(x,nchar(x)-2,nchar(x)),sep=""))
}

# This is the function to use when searching for the data on the local machine (downloaded csv files)
unidatacsvtablesgetdata <<- function(countrypartnerlist, indicatorlist, periodicity='y', periodlist = c('-1'), startperiod, endperiod, showDebugMessages=FALSE, options=''){
  #Print('Please note that the data fecthing is slow because the program if fetching all the data online in real time. We will implement caching later to speed-up the process.')
  mydatatoreturn <- emptyunidatadataframe()
  for (ind in indicatorlist){
    # print(ind)
    indcsvfolder=unidataindicatorcsvfolder(ind)
    #print(paste('_csvtables/',indcsvfolder,'/',ind,".csv",sep=''))
    #print((file.exists(paste('_/_/_csvtables/',indcsvfolder,'/',ind,".csv",sep=''))))
    if (file.exists(paste('_/_/_csvtables/',indcsvfolder,'/',ind,".csv",sep=''))){
      #print(paste('_csvtables/',ind,".csv",sep=''))
      #print("File exists")
      df <- read.csv(paste('_/_/_csvtables/',indcsvfolder,'/',ind,".csv",sep=''))
      df<-df %>% filter((countryregioncode %in% countrypartnerlist) & (timeperiod>=startperiod) & (timeperiod<=endperiod))
      df1 <- df %>% select("countryregioncode", "countryregionname", "indicatorcode", "indicatorname", "periodicity", "timeperiod", "datavalue", "datavaluecode","datavaluelabel","sourcecode", "sourcename", "sourceconsulteddate", "sourcelastupdateddate", "mainlink", "otherlinks", "flag", "notes")
      #print(head(df1))
      if (nrow(df1)>0){
        df1$api <- "csv tables"
        df1$additionalfields <- "[]"
        mydatatoreturn <- rbind(mydatatoreturn,df1)
      }
    }
  }
  return (mydatatoreturn)
}
print("Loaded function: unidatacsvtablesgetdata (countrypartnerlist, indicatorlist, periodicity, periodlist, startperiod, endperiod, showDebugMessages, options): get data from local csv tables")

# This function maps codes
unidatarecode000 <<- function(listcode, slink, regionname, codesfield, valuesfield, showDebugMessages) {
    r <- list()
    xdata <- read_sheet(slink, regionname)
    #print("data")
    #print(slink)
    #print(xdata)
    #xdata0 <- read_sheet(slink, regionname)
    #print(xdata0)
    for (v in listcode) {
        if (length(str_trim(v)) > 0 ) {
            xdata1 <- xdata %>% filter(.data[[codesfield]]==str_trim(v))
            #print(xdata1)
            r <- append(r,(xdata1[[valuesfield]][1]))
        }
        else
        {
            r <- append(r,"")
        }
    }
    return (r)
}

# Mapping function
unidatarecodedimension_00 <<- function(listcode, slink, sheetname, codesfield, valuesfield, ordersfield, ordervalue, showDebugMessages) {
    r <- list()
    xdata <- read_sheet(slink, sheetname)
    #print("data")
    #print(slink)
    #print(xdata)
    for (v in listcode) {
        #print ("V...")
        #print(v)
        if (length(str_trim(v)) > 0 ) {
            vv=""
            n=0
            vlist <- unlist(strsplit(v,"/"))
            #print("split")
            #print(vlist)
            nn= -1
            for (v0 in vlist) {
                #print("...")
                #print(str_trim(v0))
                nn=nn+1
                vv1<-str_trim(v0)
                if (length(str_trim(v)) > 0 ) {
                    xdata1 <- xdata %>% filter(.data[[codesfield]]==str_trim(vv1), grepl(paste("/",toString(nn),"/",sep=" "),.data[[ordersfield]]))
                    #print(xdata1)
                    vx=str_trim(xdata1[[valuesfield]][1])
                    if (is.null(vx)) {
                        vx=""
                    }
                    #print(vx)
                    n=n+1
                    if (n==1) {
                        vv=vx
                    }
                    else
                    {
                        vv <- paste(vv,"/",vx, sep=" ")
                    }
                }
                else
                {
                    vx  = ""
                    n=n+1
                    if (n==1) {
                        vv=vx
                    }
                    else
                    {
                        vv <- paste(vv,"/",vx, sep=" ")
                    }
                }
                #print("vv=========")
                #print(vv)
            }
            r <- append(r,vv)
        }
        else
        {
            r <- append(r,"")
        }
    }
    return (r)
}

# This is the link to the main Google sheet file
undatapcentral="https://docs.google.com/spreadsheets/d/1MHiOL_fsasbWenHOyWg8080JW88VWeyHFOj3L-hErrc/edit?usp=sharing"
unidatarecodedimension <- function(listcodes, apiname, fieldno, showDebugMessages) {
    r <- list()
    if (length(str_trim(apiname)) > 0 ) {
        slink=unidatarecode000 (c(apiname), undatapcentral, "unidataprecodecentral", "apicode", paste("v", toString(fieldno), sep = "", collapse = NULL), showDebugMessages)[[1]]
        #print("Slink:")
        #print(slink)
        if (length(str_trim(slink)) > 0){
            r <- unidatarecodedimension_00(listcodes, slink, paste("v", toString(fieldno),sep=""), "codefield","valuefield","orders", fieldno, showDebugMessages)
        }
    }
    return (r)
}


#unidatapmsctablesgetdata.R
# Getting data from files provided by users on Google sheets
unidatapmsctablesgetdata <<- function(countrypartnerlist, indicatorlist, periodicity='y', periodlist = c('-1'), startperiod, endperiod, showDebugMessages, options=''){
  msctablesindicatorsentrypoint <- read.csv("_/_/msctablesindicatorsentrypoint.csv")
  msctablesindicatorsentrypoint
  msctableslist <- list()
  typeof(msctableslist)
  for (i in indicatorlist){
    #print(i)
    data1x <- msctablesindicatorsentrypoint %>% filter(indicator==i,(!(indicator=="(test)")))
    #print(data1x)
    #print(nrow(data1x))
    if (nrow(data1x)>0){
      for (mappingt in unique(as.list(data1x$countryregmappingtable))){
        #print(mappingt)
        rnew=TRUE
        for (rec in msctableslist) {
          #print("##")
          #print(rec)
          #print(i)
          if (rec==mappingt){
            rnew=FALSE
          }
        }
        #print (rnew)
        if (rnew){
          rec = mappingt
          #print("$$")
          msctableslist[[(length(msctableslist) + 1)]] <- rec
        }
      }
    }
  }
  #print(msctableslist)
  msctablelinks<-list()
  for (tbln in msctableslist){
    #print(tbln)
    tbl<-read.csv(paste("_/_/", tbln,".csv",sep=""))
    #print(tbl)
    tbl1<-tbl %>% filter(indicator %in% indicatorlist, countrypartner %in% countrypartnerlist)
    #print(tbl1)
    for (link in unique(as.list(tbl1$msctablelink))){
      #print("...")
      #print(link)
      msctablelinks[length(msctablelinks)+1]=link
    }
  }
  #print(msctablelinks)
  mydatatoreturn0 <- emptyunidatadataframe()
  for (llink in (unique(msctablelinks))){
    #print(llink)
    datatable<-read_sheet(llink,"msctabledata")
    #print(datatable)
    datatable1<-datatable %>% filter(indicatorcode %in% indicatorlist, countryregioncode %in% countrypartnerlist, timeperiod>=startperiod,timeperiod<=endperiod)
    #print(datatable1)
    if (nrow(datatable1) > 0 ){
       datatable1$api="msc tables"
       mydatatoreturn0 <- rbind(mydatatoreturn0,datatable1)
    }
  }
  return(mydatatoreturn0)
}
print("unidatapmsctablesgetdata(countrypartnerlist, indicatorlist, startperiod, endperiod) : get data from msc tables using the unified api")


unidatapapisgetdata <<- function(countrypartnerlist, indicatorlist, periodicity='y', periodlist = c('-1'), startperiod, endperiod, showDebugMessages, options='') {
  if (showDebugMessages){
    print("Entering unidatapapisgetdata")
    print("countrypartnerlist:")
    print(countrypartnerlist)
    print("indicatorlist:")
    print(indicatorlist)
    print("startperiod:")
    print(startperiod)
    print("endperiod:")
    print(endperiod)
  }
  unidatapindicatorsentrypointmlink = "https://docs.google.com/spreadsheets/d/1z7zlAZyHMGku5QVizbLq7G0o2p8y1bUtO_qpfPug_X8/edit?usp=sharing"
  unidatapindicatorsentrypointsheetname = "unidatapindicatorsentrypoint"
  unidatapindicatorsentrypointdata <- read_sheet(unidatapindicatorsentrypointmlink,unidatapindicatorsentrypointsheetname)
  unidatapindicatorsentrypointdata
  apizoneslist <- list()
  typeof(apizoneslist)
  sp <- startperiod
  ep <- endperiod
  for (i in indicatorlist){
    #print(i)
    #print("@@@@@@@@@@@@@@@@")
    data1x <- unidatapindicatorsentrypointdata %>% filter(indicator==i)
    #print("data1x:")
    #print(data1x)
    if (nrow(data1x)>0){
      for (i in 1:nrow(data1x)){
        wbl=data1x$wbooklink[i]
        #print(wbl)
        wbr=data1x$regionname[i]
        #print(wbr)
        data2x <- read_sheet(wbl, wbr)
        #print(data2x)
        data3x1 <- data2x %>% filter(indicator %in% indicatorlist, countrypartner %in% countrypartnerlist, beginperiod <= sp, endperiod >= sp)
        data3x2 <- data2x %>% filter(indicator %in% indicatorlist, countrypartner %in% countrypartnerlist, beginperiod <= ep, endperiod >= ep)
        data3x = rbind(data3x1,data3x2)
        #print(data3x)
        #print("7890000")
        if (nrow(data3x)==0){
          data3x1 <- data2x %>% filter(indicator %in% c("(all)"), countrypartner %in% countrypartnerlist, beginperiod <= sp, endperiod >= sp)
          data3x2 <- data2x %>% filter(indicator %in% c("(all)"), countrypartner %in% countrypartnerlist, beginperiod <= ep, endperiod >= ep)
          data3x = rbind(data3x1,data3x2)         
        }
        if (nrow(data3x)==0){
          data3x1 <- data2x %>% filter(indicator %in% indicatorlist, countrypartner %in% c("(all)"), beginperiod <= sp, endperiod >= sp)
          data3x2 <- data2x %>% filter(indicator %in% indicatorlist, countrypartner %in% c("(all)"), beginperiod <= ep, endperiod >= ep)
          data3x = rbind(data3x1,data3x2)         
        }
        if (nrow(data3x)==0){
          data3x <- data2x %>% filter(indicator %in% c("(all)"), countrypartner %in% c("(all)"), beginperiod <= sp, endperiod >= sp)
        }
        for (xapi in unique(as.list(data3x$apicode))) {
          #print(xapi)
          rnew=TRUE
          #print("8890000")
          for (rec in apizoneslist) {
            #print("##")
            #print(rec)
            if (rec==xapi){
              rnew=FALSE
            }
          }
          #print (rnew)
          if (rnew){
            rec = xapi
            #print("$$")
            #print(rec)
            apizoneslist[[(length(apizoneslist) + 1)]] <- rec
          }
        }
      }
    }
  }
  #print("apizonelist")
  #print(apizoneslist)
  #print("axxx7890000")
  dff <<- emptyunidatadataframe()
  for (p in unique(apizoneslist)){
    dff0 <<- emptyunidatadataframe()
    #print(p)
    p=str_trim(p)
    unidataapigdata <<- function(countrypartnerlist, indicatorlist, periodicity='y', periodlist = c('-1'), startperiod, endperiod, showDebugMessages, options='') {
      #print("&&&&&&&&&&&&&&&&&&&")
      return (emptyunidatadataframe())
    }
    srcokfile <- paste("_/_/", p,"_okfile.txt",sep="")
    srcapifile <- paste("_/_/", p,"_definefunction.R",sep="")
    write("",srcokfile)
    #print("srcapifile:")
    #print(srcapifile)
    try(source(srcapifile)) #if successful redefines unidataapigdata and set srokfile content to "ok"
    #print(unidataapigdata(countrypartnerlist, indicatorlist, startperiod, endperiod))
    srcok <- str_trim(read_file(srcokfile))
    #print("*****")
    #print(srcok)
    if (str_trim(srcok)=="ok"){
      #print("=====ok=====")
      #print(countrypartnerlist)
      #print(indicatorlist) 
      #print(startperiod)
      #print(endperiod)
      #print(unidataapigdata(countrypartnerlist, indicatorlist, startperiod, endperiod))
      #print("!!!!!!!!!!!!!7890000")
      dff0 <<- unidataapigdata(countrypartnerlist, indicatorlist, periodlist, startperiod, endperiod, showDebugMessages, options)
      #dff0 <- emptyunidatadataframe() #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      #print(dff0)
      #print("!!!@@@!!!")
      if (nrow(dff0)>0){
        dff0$api<-"APIs"
      }
    }
    else
    {
      dff0 <<- emptyunidatadataframe()
    }
    #print("++++++++")
    #print(dff0)
    dff <<- rbind(dff, dff0)
  }
  return(dff)
}
print("unidatapapisgetdata(countrypartnerlist, indicatorlist, startperiod, endperiod) : get data from apis using the unified api")

unidatapgetdata <<- function(countrypartnerlist, indicatorlist, periodicity='y', periodlist = c('-1'), startperiod, endperiod, showDebugMessages=FALSE, options=''){
  print('Please note that the data fecthing is slow because the program if fetching all the data online in real time. We will implement caching later to speed-up the process.')
  print("Trying to find the source for this indicator ...")
  print("Getting the data from the msc tables sub-system ....")
  if (showDebugMessages) {print("Getting the data from the msc tables sub-system ....")}
  tmpdf1<-unidatapmsctablesgetdata (countrypartnerlist, indicatorlist, startperiod, endperiod, showDebugMessages)
  if (TRUE) {
    if (nrow(tmpdf1)>0){
      tmpdf1$api <- "msc tables"
      print(paste("Got ", toString(nrow(tmpdf1)), " rows from the msc tables sub-system"),sep="")
    }
    else
    {
      print("Got no data from the msc tables sub-system")
    }
  }
  if (TRUE) {print("Getting the data from the APIs mapping sub-system ....")}
  tmpdf2<-unidatapapisgetdata (countrypartnerlist, indicatorlist, periodicity, periodlist, startperiod, endperiod, showDebugMessages, options='')
  if (TRUE) {
    if (nrow(tmpdf2)>0){
      print(paste("Got ", toString(nrow(tmpdf2)), " rows from the APIs mapping sub-system"),sep="")
    }
    else
    {
      print("Got no data from the APIs mapping sub-system")
    }
  }
  tmpdf1$sourceconsulteddate<-as.character(tmpdf1$sourceconsulteddate)
  tmpdf1$sourcelastupdateddate<-as.character(tmpdf1$sourcelastupdateddate)
  tmpdf2$sourceconsulteddate<-as.character(tmpdf2$sourceconsulteddate)
  tmpdf2$sourcelastupdateddate<-as.character(tmpdf2$sourcelastupdateddate)
  tmpdf3<-rbind(tmpdf1,tmpdf2)
  if (TRUE) {print("Getting the data from the csv tables sub-system ....")}
  tmpdf4<-unidatacsvtablesgetdata (countrypartnerlist, indicatorlist, startperiod, endperiod, showDebugMessages)
  if (showDebugMessages) {
    if (nrow(tmpdf4)>0){
      print(paste("Got ", toString(nrow(tmpdf4)), " rows from the csv tables sub-system"),sep="")
    }
    else
    {
      print("Got no data from the csv tables sub-system")
    }
  }
  tmpdf3$sourceconsulteddate<-as.character(tmpdf3$sourceconsulteddate)
  tmpdf3$sourcelastupdateddate<-as.character(tmpdf3$sourcelastupdateddate)
  tmpdf4$sourceconsulteddate<-as.character(tmpdf4$sourceconsulteddate)
  tmpdf4$sourcelastupdateddate<-as.character(tmpdf4$sourcelastupdateddate)
  tmpdf<-rbind(tmpdf3,tmpdf4)
  print("===== results =======")
  print(paste(nrow(tmpdf)," rows returned.",sep=""))
  return(tmpdf)
}
print("unidatapgetdata(countrypartnerlist, indicatorlist, periodicity, startperiod, endperiod) : get data using the unified api")

unidataprocessmsctable <<- function(msctablelink, msctablename, showDebugMessages)
{
  msctablesindicatorsentrypoint<-read.csv("_/_/msctablesindicatorsentrypoint.csv")
  tablelink=msctablelink
  #print(tablelink)
  tablename=msctablename
  #print(tablename)
  sdata<-read_sheet(tablelink,"msctabledata")
  #print(sdata)
  #print(unique(sdata$indicatorcode))
  for (ind in unique(sdata$indicatorcode)){
    #print(ind)
    sdata1<-sdata %>% filter(indicatorcode==ind)
    #print(sdata1)
    if (nrow(sdata1)>0){
      for (ccd in unique(sdata1$countryregioncode )){
        #print(ccd)
        sdata2<-sdata1 %>% filter(countryregioncode==ccd)
        ccdmappingtablename=paste("_/_/", str_trim(str_split(ccd,"/")[1]),"_imapping",sep="")
        #print(ccdmappingtablename)
        mt<-msctablesindicatorsentrypoint %>% filter(indicator==ind,countryregmappingtable==ccdmappingtablename)
        #print(mt)
        #print(nrow(mt))
        if (nrow(mt)==0){
          msctablesindicatorsentrypoint[nrow(msctablesindicatorsentrypoint)+1,]=c(ind,ccdmappingtablename)
        }
        if ((file.exists(paste(ccdmappingtablename,".csv",sep="")))){
          mfile<-read.csv(paste(ccdmappingtablename,".csv",sep=""))
        }
        else
        {
          mfile <- data.frame(indicator=character(),
                              countrypartner=character(),
                              msctablelink=character(),
                              periodicity=character(),
                              beginperiod=character(),
                              endperiod=character())
        }
        #print(mfile)
        prdcity=max(sdata2$periodicity)
        #print(prdcity)
        minp=min(sdata2$timeperiod)
        #print(minp)
        maxp=max(sdata2$timeperiod)
        #print(maxp)
        mfilefiltered<-mfile %>% filter(indicator==ind,countrypartner==ccd,msctablelink==tablelink)
        #print(mfilefiltered)
        #print(nrow(mfilefiltered))
        if (nrow(mfilefiltered)==0){
          mfile[nrow(mfile)+1,]=c(ind,ccd,tablelink,prdcity,minp,maxp)
          write.csv(mfile,paste(ccdmappingtablename,".csv",sep=""),row.names = FALSE)
        }
      }
    }
  }
  write.csv(msctablesindicatorsentrypoint,"_/_/msctablesindicatorsentrypoint.csv",row.names = FALSE)
}
print("unidataprocessmsctable(tablelink, tablename) : process one msc table")

unidataprocessmsctables <<- function(showdebugmessages){
  nnow<-function(){
    return (as.POSIXct(as.numeric(Sys.time()), format = '%Y-%m-%d T %H:%M:%S'))
  }
  undatapcentral="https://docs.google.com/spreadsheets/d/1MHiOL_fsasbWenHOyWg8080JW88VWeyHFOj3L-hErrc/edit?usp=sharing"
  msctablesondisc <<- read.csv("msctables.csv")
  msctablesondisc$msctablestatus <- "(unactive)"
  msctablesondisc<<-subset(msctablesondisc, !(msctablelink=="(test)"))
  #print(msctablesondisc)
  msctablesonline<-read_sheet(undatapcentral,"msctables")
  msctablesonline<<-subset(msctablesonline, !(msctablelink=="(test)"))
  msctablesonline<<-read_sheet(undatapcentral,"msctables")
  #print(msctablesonline)
  for (i in 1:nrow(msctablesonline)){
    #print (i)
    tablelink=msctablesonline$msctablelink[i]
    #print(tablelink)
    tablename=msctablesonline$msctablename[i]
    #print(tablename)
    tableversion=msctablesonline$msctableversion[i]
    #print(tableversion)
    #print(colnames(msctablesondisc))
    if (!(tablelink=="(test)")) {
      rondisc <- msctablesondisc %>% filter(msctablelink==tablelink)
      #print("-----")
      #print(rondisc)
      #print(nrow(rondisc))
      vmsctablelink=tablelink
      vmsctablename=tablename
      vmsctableversion=tableversion
      vmsctablestatus="active"
      vmsctabledatecreated=nnow()
      vmsctabledateprocessed=nnow()
      if (nrow(rondisc)>0) {
        tableoldversion=as.numeric(min(rondisc$msctableversion))
        if (tableversion>tableoldversion)
        {
          print("process updated table")
          unidataprocessmsctable(tablelink, tablename)
          msctablesondisc$msctablename[msctablesondisc$msctablelink==vmsctablelink] <- vmsctablename
          msctablesondisc$msctableversion[msctablesondisc$msctablelink==vmsctablelink] <- vmsctableversion
          msctablesondisc$msctablestatus[msctablesondisc$msctablelink==vmsctablelink] <- vmsctablestatus
          msctablesondisc$msctabledateprocessed[msctablesondisc$msctablelink==vmsctablelink] <- vmsctabledateprocessed
        }
        else
        {
          print("update just table fields")
          #print(msctablesondisc)
          msctablesondisc$msctablename[msctablesondisc$msctablelink==vmsctablelink] <- vmsctablename
          msctablesondisc$msctablestatus[msctablesondisc$msctablelink==vmsctablelink] <- vmsctablestatus
        }
      }
      else
      {
        print("process new table")
        unidataprocessmsctable(tablelink, tablename)
        msctablesondisc[nrow(msctablesondisc)+1,] <- c(vmsctablelink, vmsctablename, vmsctableversion, vmsctablestatus, vmsctabledatecreated, vmsctabledateprocessed)
      }
    }
  }
  write.csv(msctablesondisc,"_/_/msctables.csv",row.names=FALSE)
}
print("unidataprocessmsctables() : process new msc tables")

searchunidatapindicator <<- function(lang,searchkeywords, showdebugmessages=FALSE, options=''){
  downloadindicators = FALSE
  savedindicators = "_/_/_saved_indicators_list.csv"
  file.exists(savedindicators)
  ilastsaved = file.info(savedindicators)$ctime
  if (is.na(ilastsaved)) {
    ilastsaved = "1900-01-01"
  }
  if (difftime(Sys.Date(), ilastsaved, units = "days") >= 60) {
    downloadindicators = TRUE
  }
  if (downloadindicators) {
    print ("Downloading indicators list")
    unidatapcentralrclink="https://docs.google.com/spreadsheets/d/1MHiOL_fsasbWenHOyWg8080JW88VWeyHFOj3L-hErrc/edit?usp=sharing"
    unidatapcentralrclsheet="allindicators"
    unidatapindicators <<- read_sheet(unidatapcentralrclink,unidatapcentralrclsheet)
    #print(unidatapindicators)
    unidatapindicators$searchindicatorfield_en = paste(unidatapindicators$indicatorname_en, ' ~ ', unidatapindicators$indicatorkeywords_en, '')
    unidatapindicators$searchindicatorfield_fr = paste(unidatapindicators$indicatorname_fr, ' ~ ', unidatapindicators$indicatorkeywords_fr, '')
    write.csv(unidatapindicators, savedindicators, row.names = FALSE)
  }
  else
  {
    unidatapindicators <- read.csv(savedindicators)
  }
  d00x<<-unidatapindicators %>% filter(FALSE)
  if (str_length(searchkeywords)>0){
    for (cr in unlist(str_split(searchkeywords,";"))){
      #print(cr)
      cr <- str_trim(cr)
      if (str_length(cr)>0){
        d00<<-unidatapindicators
        for (cr1 in unlist(str_split(cr,"\\+"))){
          #print(cr1)
          for (term in cr1){
            term<-str_trim(term)
            #print(term)
            if (str_length(term)>0){
              if (str_trim(tolower(lang))=="fr") {
                d00 <<- d00 %>% filter(grepl(tolower(term),tolower(searchindicatorfield_fr)))
              }
              else
              {
                d00 <<- d00 %>% filter(grepl(tolower(term),tolower(searchindicatorfield_en)))
              }
              #print(d00)
            }
          }
          #print(d00)
          d00x<<-rbind(d00x,d00)
        }
      }
    }
  }
  return(d00x %>% select('indicatorname', 'indicatorcode'))
}

unidataapifindi <<- function(lang, searchkeywords, showdebugmessages, options){
  return (searchunidatapindicator(lang, searchkeywords, showdebugmessages, options))
}
searchunidatapicountryregion <<- function(lang,searchkeywords, showdebugmessages, options){
  unidatapcentralrclink="https://docs.google.com/spreadsheets/d/1MHiOL_fsasbWenHOyWg8080JW88VWeyHFOj3L-hErrc/edit?usp=sharing"
  unidatapcentralrclsheet="allcountriesregions"
  unidatapicountriesregions <<- read_sheet(unidatapcentralrclink,unidatapcentralrclsheet)
  #print(unidatapindicators)
  unidatapicountriesregions$searchfield_en = paste(unidatapicountriesregions$country_or_region_name_en, ' ~ ', unidatapicountriesregions$country_or_region_keywords_en, '')
  unidatapicountriesregions$searchfield_fr = paste(unidatapicountriesregions$country_or_region_name_fr, ' ~ ', unidatapicountriesregions$country_or_region_keywords_fr, '')
  d00x<<-unidatapicountriesregions %>% filter(FALSE)
  if (str_length(searchkeywords)>0){
    for (cr in unlist(str_split(searchkeywords,";"))){
      #print(cr)
      cr <- str_trim(cr)
      if (str_length(cr)>0){
        d00<<-unidatapicountriesregions
        for (cr1 in unlist(str_split(cr,"\\+"))){
          #print(cr1)
          for (term in cr1){
            term<-str_trim(term)
            #print(term)
            if (str_length(term)>0){
              if (str_trim(tolower(lang))=="fr") {
                d00 <<- d00 %>% filter(grepl(tolower(term),tolower(searchfield_fr)))
              }
              else
              {
                d00 <<- d00 %>% filter(grepl(tolower(term),tolower(searchfield_en)))
              }
              #print(d00)
            }
          }
          #print(d00)
          d00x<<-rbind(d00x,d00)
        }
      }
    }
  }
  return(d00x)
}
unidataapifindcr <<- function(lang, searchkeywords, showdebugmessages, options){
  return (searchunidatapicountryregion(lang, searchkeywords, showdebugmessages, options))
}
print ("searchunidatapindicator (language, searchcriteria): search indicators by keywords")
print ("searchunidatapindicator ('en or fr', 'c1|c2 + c3|c4 ; c4|c5|c6 + c7') : search indicators by keywords ((c1 or c2) and (c3 or c4)) OR ((c4 or c5 or c6) and c7)")

unidatapexpandilistviarecoding <<- function(indicatorlist, showDebugMessages){
  indicatorlist1 <-indicatorlist
  unidatapirecs <- read_sheet("https://docs.google.com/spreadsheets/d/1MHiOL_fsasbWenHOyWg8080JW88VWeyHFOj3L-hErrc/edit?usp=sharing","indicatorsrecoding")
  u1<-unidatapirecs %>% filter(unidatapirecs$initial %in% indicatorlist)
  indicatorlist1 <- unique(append(indicatorlist1,unlist(u1$recoded)))
  u1<<-unidatapirecs %>% filter(unidatapirecs$recoded %in% indicatorlist)
  indicatorlist1 <- unique(append(indicatorlist1,unlist(u1$initial)))
  return (indicatorlist1)
}
print("unidatapexpandilistviarecoding (indicatorlist): expand indicators lists based on indicators mappings")

#unidatapexpanddataviarecoding
unidatapexpanddataviarecoding <<- function (inputdataset, showDebugMessages) {
  xpdata <<- inputdataset
  unidatapirecs <<- read_sheet("https://docs.google.com/spreadsheets/d/1MHiOL_fsasbWenHOyWg8080JW88VWeyHFOj3L-hErrc/edit?usp=sharing","indicatorsrecoding")
  u1<<-unidatapirecs %>% filter(unidatapirecs$initial %in% indicatorlist)
  if (nrow(u1)>0) 
  {
    for (i in 1:nrow(u1))
    {
      xinitial <- u1$initial[i]
      #print(xinitial)
      xinitialname <- u1$initialname[i]
      #print(xinitialname)
      xrecoded <- u1$recoded[i]
      #print(xrecoded)
      xrecodedname <- u1$recodedname[i]
      #print(xrecodedname)
      xfactor <- as.numeric(u1$scalingfactor[i])
      #print(xfactor)
      xrcode <- u1$recodecode[i]
      #print(xrcode)
      ux0 <<- xpdata %>% filter(xpdata$indicatorcode==xinitial,, (!grepl(paste("[",str_trim(tolower(xrcode)),"]",sep=""),sourcecode)))
      #print(ux0)
      ux0$datavalue=xfactor*ux0$datavalue
      ux0$indicatorcode=xrecoded
      ux0$indicatorname=xrecodedname
      ux0$sourcecode=paste(ux0$sourcecode,">>[",str_trim(tolower(xrcode)), "]",sep="")
      #print(ux0)
      
      ux1 <<- xpdata %>% filter(xpdata$indicatorcode==xrecoded, (!grepl(paste("[",str_trim(tolower(xrcode)),"]",sep=""),sourcecode)))
      #print(ux1)
      ux1$datavalue=ux1$datavalue/xfactor
      ux1$indicatorcode=xinitial
      ux1$indicatorname=xinitialname
      ux1$sourcecode=paste(ux1$sourcecode,"<<[",str_trim(tolower(xrcode)),"]",sep="")
      #print(ux1)
      xpdata <<- rbind(xpdata,ux0)
      xpdata <<- rbind(xpdata,ux1)
    }
  }
  return(xpdata)
}
print("unidatapexpanddataviarecoding (inputdataset): complete dataset using indicators mapping")