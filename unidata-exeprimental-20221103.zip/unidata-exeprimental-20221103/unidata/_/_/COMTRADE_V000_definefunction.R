# FAOSTAT_QCL_definefunction.R
print("Matching function unidataapigdata COMTRADE_wrapper.......")

library(rjson)
string <- "http://comtrade.un.org/data/cache/partnerAreas.json"
reporters <- fromJSON(file=string)
reporters <- as.data.frame(t(sapply(reporters$results,rbind)))
get.Comtrade <<- function(url="http://comtrade.un.org/api/get?"
                          ,maxrec=50000
                          ,type="C"
                          ,freq="A"
                          ,px="HS"
                          ,ps="now"
                          ,r
                          ,p
                          ,rg="all"
                          ,cc="TOTAL"
                          ,fmt="json"
)
{
  string<- paste(url
                 ,"max=",maxrec,"&" #maximum no. of records returned
                 ,"type=",type,"&" #type of trade (c=commodities)
                 ,"freq=",freq,"&" #frequency
                 ,"px=",px,"&" #classification
                 ,"ps=",ps,"&" #time period
                 ,"r=",r,"&" #reporting area
                 ,"p=",p,"&" #partner country
                 ,"rg=",rg,"&" #trade flow
                 ,"cc=",cc,"&" #classification code
                 ,"fmt=",fmt        #Format
                 ,sep = ""
  )
  
  if(fmt == "csv") {
    raw.data<- read.csv(string,header=TRUE)
    return(list(validation=NULL, data=raw.data))
  } else {
    if(fmt == "json" ) {
      raw.data<- fromJSON(file=string)
      data<- raw.data$dataset
      validation<- unlist(raw.data$validation, recursive=TRUE)
      ndata<- NULL
      if(length(data)> 0) {
        var.names<- names(data[[1]])
        data<- as.data.frame(t( sapply(data,rbind)))
        ndata<- NULL
        for(i in 1:ncol(data)){
          data[sapply(data[,i],is.null),i]<- NA
          ndata<- cbind(ndata, unlist(data[,i]))
        }
        ndata<- as.data.frame(ndata)
        colnames(ndata)<- var.names
      }
      return(list(validation=validation,data =ndata))
    }
  }
}

unidataapigdata <<- function(countrypartnerlist, indicatorlist, periodicity='y', periodlist=c('-1'), startperiod, endperiod, showDebugMessages, options='') {
    print("@@@@@@@@@@@@@@@@@@@@@222")
    mydatatoreturn <- emptyunidatadataframe()
    ddf<-emptyunidatadataframe()
    allcountries<-read_sheet(undatapcentral,"allcountriesregions")
    print(allcountries)
    for (cp in countrypartnerlist){
      if (length(unlist(strsplit(cp, ":")))==2){
        reporter0<-trimws(unlist(strsplit(cp, ":"))[1])
        print(reporter0)
        reporter1list = unidatarecodedimension(c(reporter0),"COMTRADE_V000",2)
        if (length(reporter1list)==1){
          reporter1 = trimws(unlist(reporter1list)[1])
          if (length(reporter1) > 0 ) {
            partner0<-trimws(unlist(strsplit(cp, ":"))[2])
            print(partner0)
            partner1list = unidatarecodedimension(c(partner0),"COMTRADE_V000",2)
            if (length(partner1list)==1){
              partner1 = unlist(partner1list)[1]
              print(reporter1)
              print(partner1)
              if (length(reporter1) > 0 ) {
                for (ind in indicatorlist) {
                  print("Indicator:")
                  print(ind)
                  print(length(unlist(strsplit(ind,"~"))))
                  if (length(unlist(strsplit(ind,"~")))==5){
                    tradeflow = trimws(unlist(strsplit(ind,"~"))[1])
                    print("Trade flow:")
                    print(tradeflow)
                    tf =0
                    if (tradeflow=="Export") {tf=2}
                    if (tradeflow=="Import") {tf=1}
                    commodity = trimws(unlist(strsplit(ind,"~"))[2])
                    print("commodity:")
                    print(commodity)
                    periodicity = trimws(unlist(strsplit(ind,"~"))[3])
                    print("periodicity:")
                    print(periodicity)
                    classification = trimws(unlist(strsplit(ind,"~"))[4])
                    print("classification:")
                    print(classification)
                    classificationcode = trimws(unlist(strsplit(ind,"~"))[5])
                    print("classificationcode:")
                    print(classificationcode)
                    ctdata<- get.Comtrade("http://comtrade.un.org/api/get?"
                                          ,50000
                                          ,commodity
                                          ,periodicity
                                          ,classification
                                          ,"2000,2018"
                                          ,reporter1
                                          ,partner1
                                          ,tf
                                          ,classificationcode
                                          ,"json"
                    )
                    ddf1<-ctdata$data
                    if (is.null(ddf1)){}
                    else
                    {
                      ddf1$indicatorcode <- ind
                      ddf1$countryregioncode_reporter <- reporter1
                      ddf1$countryregioncode_partner <- partner1
                      ddf1$countryregioncode <- paste(reporter1, " - : - ", partner1, sep="")
                      mycdatar<-allcountries %>% filter(country_or_region_codercode==reporter0)
                      print("****")
                      print(mycdatar)
                      country_namer = toString(mycdatar$country_or_region_name[[1]])
                      
                      mycdatap<-allcountries %>% filter(country_or_region_codercode==partner0)
                      print("****")
                      print(mycdatap)
                      country_namep = toString(mycdatap$country_or_region_name[[1]])
                      ddf1$countryregionname_reporter <- country_namer
                      ddf1$countryregionname_partner <- country_namep
                      ddf1$countryregionname <- paste(country_namer, " - : - ", country_namep, sep="")
                      print(ddf1)
                      print(nrow(ddf1))
                      if (nrow(ddf1)>0) {
                        if (nrow(ddf)>0){
                          ddf<-rbind(ddf,ddf1)
                        }
                        else{
                          ddf<-ddf1
                        }
                        print("%%%%%%%%%%%%%%")
                        print(ddf)
                      }}     
                  }
                }
              }
            }
          }
        }
      }
    }
    nnow<-function(){
      return (as.POSIXct(Sys.time(), format = '%Y-%m-%d T %H:%M:%S'))
    }
    myfiltereddata <-ddf
    sourceconsulteddate=format(nnow(),"%Y-%m-%d %H:%M:%S")
    if (nrow(myfiltereddata)>0){
      #myfiltereddata$countryregionname <- ""
      #myfiltereddata$indicatorcode <- ""
      myfiltereddata$indicatorname  <- ""
      #myfiltereddata$ountryname_reporter  <- ""
      #myfiltereddata$ountryname_partner  <- ""
      #myfiltereddata$countryregioncode <- paste(myfiltereddata$countryregioncode_reporter," - : - ",myfiltereddata$countryregioncode_partner, sep="")
      #myfiltereddata$ountryregionname  <- ""
      myfiltereddata$periodicity  <- periodicity
      myfiltereddata$timeperiod  <- myfiltereddata$period
      myfiltereddata$datavalue  <- myfiltereddata$TradeValue
      myfiltereddata$datavaluecode  <- "..."
      myfiltereddata$datavaluelabel  <- "..."
      myfiltereddata$sourcecode <- "COMTRADE" 
      myfiltereddata$sourcename  <- "COMTRADE"
      myfiltereddata$sourceconsulteddate  <- sourceconsulteddate
      myfiltereddata$sourcelastupdateddate <- ""
      myfiltereddata$mainlink  <- "..."
      myfiltereddata$otherlinks  <- "..."
      myfiltereddata$flag <- ""
      myfiltereddata$notes <- ""
      n=0
      print("784444444!  3 2")
      
      n=0
      #for (c0 in countrypartnerlist){
      #country_code = c0
      #mycdata<-allcountries %>% filter(country_or_region_codercode==c0)
      #print(toString(mycdata$country_or_region_name[[1]]))
      #country_name = toString(mycdata$country_or_region_name[[1]])
      #myfiltereddata$countryregionname[myfiltereddata$countryregioncode==c0] <- country_name
      #}
      print("784444444!  4")
      allindicators<-read_sheet(undatapcentral,"allindicators")
      n=0
      for (i0 in indicatorlist){
        indicator_code = i0
        print("i indicator code")
        print(indicator_code)
        myidata<-allindicators %>% filter(indicatorcode==i0)
        #print(toString(myidata$indicatorname[[1]]))
        indicator_name = toString(myidata$indicatorname[[1]])
        myfiltereddata$indicatorname[myfiltereddata$indicatorcode==i0] <- indicator_name
      }
    }
    mydatatoreturn<-myfiltereddata %>% select("countryregioncode", "countryregionname", "indicatorcode", "indicatorname", "periodicity", "timeperiod", "datavalue", "datavaluecode","datavaluelabel","sourcecode", "sourcename", "sourceconsulteddate", "sourcelastupdateddate", "mainlink", "otherlinks", "flag", "notes")
    print("================================================")
    print(mydatatoreturn)
    return(mydatatoreturn)
  }
print("Matched function unidataapigdata FAOSTAT_RFB_wrapper")
write("ok", "COMTRADE_V000_okfile.txt")