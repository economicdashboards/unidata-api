# FAOSTAT_QCL_definefunction.R
print("Matching function unidataapigdata FAOSTAT_RFB_wrapper.......")
unidataapigdata <<- function(countrypartnerlist, indicatorlist, periodlist=c(-1), startperiod, endperiod, showDebugMessages=FALSE, options='') {
    print("@@@@@@@@@@@@@@@@@@@@@222")
    mydatatoreturn <- emptyunidatadataframe()
    addpackages (c("FAOSTAT"))
    countrypartnerlistrecoded <- unidatarecodedimension(countrypartnerlist,"FAOSTAT_RFB",2)
    #print(countrypartnerlistrecoded) #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    indicatorlistrecoded <- unidatarecodedimension(indicatorlist,"FAOSTAT_RFB",1)
    #print(indicatorlistrecoded) #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    datasetcode="RFB"
    datasetfolder = paste("_/FAOSTAT/", datasetcode, sep="")
    nnow<-function(){
      return (as.POSIXct(Sys.time(), format = '%Y-%m-%d T %H:%M:%S'))
    }
    if (!(dir.exists(datasetfolder))){
      #print("ooo") #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      dir.create(datasetfolder)
    }
    mquery<-FAOsearch(code=datasetcode)
    date0<-paste(str_replace(mquery$dateupdate[1],"T"," ")," CET",sep="")
    #print(date0) #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    #date online file was updated online
    dateOnlinefilewasupdatedonline<-as.POSIXlt(date0, format="%Y-%m-%d %H:%M:%S")
    #print(dateOnlinefilewasupdatedonline) #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    filetoStoredateOfflineFilewasupdatedonline<-paste(datasetfolder,"/",datasetcode,"_lupd.txt", sep="")
    #print(filetoStoredateOfflineFilewasupdatedonline) #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    if (!(file.exists(filetoStoredateOfflineFilewasupdatedonline))){
      write("2000-01-01 00:00:00 CET",filetoStoredateOfflineFilewasupdatedonline)
    }
    dateOfflinefilewasupdatedonline<-as.POSIXct(str_trim(read_file(filetoStoredateOfflineFilewasupdatedonline)), format="%Y-%m-%d %H:%M:%S")
    #print(dateOfflinefilewasupdatedonline) #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    filetoStoredateOfflineFilewasdownloaded<-paste(datasetfolder,"/",datasetcode,"_ldwnld.txt", sep="")
    
    #print(filetoStoredateOfflineFilewasdownloaded) #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    
    if (!(file.exists(filetoStoredateOfflineFilewasdownloaded))){
      write("2000-01-01T00:00:00 CET",filetoStoredateOfflineFilewasdownloaded)
    }
    
    dateOfflineFilewasdownloaded<-as.POSIXct(str_trim(read_file(filetoStoredateOfflineFilewasdownloaded)), format="%Y-%m-%d %H:%M:%S")
    
    #print(dateOfflineFilewasdownloaded) #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    dwldfile<-FALSE #indicates whether we need to download the file
    
    # If the file was updated online after the file was downloaded
    if (as.numeric(difftime(dateOnlinefilewasupdatedonline, dateOfflinefilewasupdatedonline, units = "days"))>1.5){
      dwldfile<-TRUE
    }
    print("784444444!")
    # If the file was updated online is very diiferent from the date the file was downloaded
    if (as.numeric(difftime(dateOnlinefilewasupdatedonline, dateOfflinefilewasupdatedonline, units = "days"))<(-1.5)){
      dwldfile<-TRUE
    }
    
    # If the dates of last update of the offline and online files are different
    if (as.numeric(difftime(dateOnlinefilewasupdatedonline, dateOfflinefilewasupdatedonline, units = "days"))<=1){
      if (as.numeric(difftime(dateOnlinefilewasupdatedonline, dateOfflinefilewasupdatedonline, units = "days"))>=(-1)){
        if (as.numeric(difftime(nnow(), dateOfflinefilewasupdatedonline, units = "days"))>=(1)){
          if (as.numeric(difftime(nnow(), dateOfflinefilewasupdatedonline, units = "days"))<=(30)){
            if (as.numeric(difftime(nnow(), dateOfflineFilewasdownloaded, units = "days"))>=(7)){
              dwldfile<-TRUE
            }
          }
        }
      }  
    }
    
    if (as.numeric(difftime(dateOnlinefilewasupdatedonline, dateOfflinefilewasupdatedonline, units = "days"))<=1){
      if (as.numeric(difftime(dateOnlinefilewasupdatedonline, dateOfflinefilewasupdatedonline, units = "days"))>=(-1)){
        if (as.numeric(difftime(nnow(), dateOnlinefilewasupdatedonline, units = "days"))>=(1)){
          if (as.numeric(difftime(nnow(), dateOnlinefilewasupdatedonline, units = "days"))<=(120)){
            if (as.numeric(difftime(nnow(), dateOfflineFilewasdownloaded, units = "days"))>=(30)){
              dwldfile<-TRUE
            }
          }
        }
      }  
    }
    print("784444444!  2")
    #print(dwldfile) #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    rdffilename<-offlinefileldwnld<-paste(datasetfolder,"/",datasetcode,"_data.rdf", sep="")
    #print(rdffilename) #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    # If there is no .rdf file
    if (!(file.exists(rdffilename))){
      dwldfile<-TRUE
    }
    #print(dwldfile) #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    # set the name of the zip file
    zipfilename<-paste(datasetfolder,"/", toString(basename(mquery$filelocation[1])), sep="",collapse=NULL)
    #print(nnow()) #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    datejustbeforedownload <- nnow()
    #download the file if necessary
    if (dwldfile) {
      print("QCL dataset needs to be updated. Downloading from FAO website ....") #!!!!!!!!!!!!!!!!!!!!!!!
      if ((file.exists(rdffilename))){
        #delete rdffilename
      }
      if ((file.exists(zipfilename))){
        #delete zipfilename
      }
      mydata_file <- get_faostat_bulk(code = datasetcode, data_folder = datasetfolder)
      mydata_file$indicator <- paste("i",str_trim(mydata_file$element_code),"x",str_trim(mydata_file$item_code), sep="")
      # Cache the file i.e. save the data frame in the serialized RDS format for faster load time later.
      saveRDS(mydata_file, rdffilename)
      # Now you can load your local version of the data from the RDS file
      write(format(dateOnlinefilewasupdatedonline,"%Y-%m-%d %H:%M:%S"),filetoStoredateOfflineFilewasupdatedonline)
      write(format(datejustbeforedownload,"%Y-%m-%d %H:%M:%S"),filetoStoredateOfflineFilewasdownloaded)
    }
    print("784444444!  3")
    #read the file
    mydata_file <- readRDS(rdffilename)
    #set the dates
    print("784444444!  3 1")
    print("countrypartnerlistrecoded:")
    print(countrypartnerlistrecoded)
    print("indicatorlistrecoded:")
    print(indicatorlistrecoded)
    print("startperiod:")
    print(startperiod)
    print("endperiod:")
    print(endperiod)
    print("data:")
    print(head(mydata_file,10))
    myfiltereddata <- mydata_file %>% filter(area_code %in% countrypartnerlistrecoded, indicator %in% indicatorlistrecoded, year>=startperiod,year<=endperiod)
    if (nrow(myfiltereddata)>0){
            print("784444444!  3 1 1")
            sourceconsulteddate=format(nnow(),"%Y-%m-%d %H:%M:%S")
            print(myfiltereddata$countryregioncode)
            myfiltereddata$countryregioncode <- ""
            print("784444444!  3 1 1x")
            myfiltereddata$countryregionname <- ""
            myfiltereddata$indicatorcode <- ""
            myfiltereddata$indicatorname  <- ""
            myfiltereddata$periodicity  <- "A"
            myfiltereddata$timeperiod  <- myfiltereddata$year
            myfiltereddata$datavalue  <- myfiltereddata$value
            myfiltereddata$datavaluecode  <- "..."
            myfiltereddata$datavaluelabel  <- "..."
            myfiltereddata$sourcecode <- "FAOSTAT/QCL" 
            myfiltereddata$sourcename  <- "FAO statistical database - production - crops and livestock products"
            myfiltereddata$sourceconsulteddate  <- sourceconsulteddate
            myfiltereddata$sourcelastupdateddate <- format(dateOnlinefilewasupdatedonline,"%Y-%m-%d %H:%M:%S")
            myfiltereddata$mainlink  <- "..."
            myfiltereddata$otherlinks  <- "..."
            myfiltereddata$flag <- ""
            myfiltereddata$notes <- myfiltereddata$flag
            n=0
            print("784444444!  3 1 2")
            for (c0 in countrypartnerlist){
              inicountry = c0
              n=n+1
              recodedcountry = countrypartnerlistrecoded[[n]]
              myfiltereddata$countryregioncode[myfiltereddata$area_code==recodedcountry] <- inicountry
            }
            print("784444444!  3 2")
            n=0
            for (i0 in indicatorlist){
              iniindicator = i0
              n=n+1
              recodedindicator = indicatorlistrecoded[[n]]
              myfiltereddata$indicatorcode[myfiltereddata$indicator==recodedindicator] <- iniindicator
            }
            print("784444444!  3 3")
            allcountries<-read_sheet(undatapcentral,"allcountriesregions")
            n=0
            for (c0 in countrypartnerlist){
              country_code = c0
              mycdata<-allcountries %>% filter(country_or_region_codercode==c0)
              #print(toString(mycdata$country_or_region_name[[1]]))
              country_name = toString(mycdata$country_or_region_name[[1]])
              myfiltereddata$countryregionname[myfiltereddata$countryregioncode==c0] <- country_name
            }
            print("784444444!  4")
            allindicators<-read_sheet(undatapcentral,"allindicators")
            n=0
            for (i0 in indicatorlist){
              indicator_code = i0
              print("i indicator code")
              print(indicator_code)
              myidata<-allindicators %>% filter(indicatorcode==i0)
              #print(toString(myidata$indicatorname[[1]]))
              indicator_name = toString(myidata$indicatorname[[1]])
              myfiltereddata$indicatorname[myfiltereddata$indicatorcode==i0] <- indicator_name
            }
        }
        mydatatoreturn<-myfiltereddata %>% select("countryregioncode", "countryregionname", "indicatorcode", "indicatorname", "periodicity", "timeperiod", "datavalue", "datavaluecode","datavaluelabel","sourcecode", "sourcename", "sourceconsulteddate", "sourcelastupdateddate", "mainlink", "otherlinks", "flag", "notes")
        return(mydatatoreturn)
  }
print("Matched function unidataapigdata FAOSTAT_RFB_wrapper")
write("ok", "_/_/FAOSTAT_RFB_okfile.txt")