# This is the main function that goes through the different wrappers to get the data
# Countrypartnerlist : list of the country codes in the form: c('AFG','BEN','NGA', '...'). In case of country and partner: c('FRA-GAB','NGA-CAM','....')
# indicatorlist : list of the indicators codes in the form: c('indicator code 1','indicator code 2','indicator code 3', '...')
# Periodicity : 'y' for year
# Periodlist : list of periods in the form: c('2012','2013','...'). If not used (using startperiod and endperiod instead), put c('-1')

unidatapapisgetdata <<- function(countrypartnerlist, indicatorlist, periodicity='y', preiodlist=c('-1'), startperiod, endperiod, showDebugMessages=FALSE, options = '') {
  if (showDebugMessages){
    print("Entering unidatapapisgetdata")
    print("countrypartnerlist:")
    print(countrypartnerlist)
    print("indicatorlist:")
    print(indicatorlist)
    print("startperiod:")
    print(startperiod)
    print("endperiod:")
    print(endperiod)
  }
  #Print('Please note that the data fecthing is slow because the program if fetching all the data online in real time. We will implement caching later to speed-up the process.')
  unidatapindicatorsentrypointmlink = "https://docs.google.com/spreadsheets/d/1z7zlAZyHMGku5QVizbLq7G0o2p8y1bUtO_qpfPug_X8/edit?usp=sharing"
  unidatapindicatorsentrypointsheetname = "unidatapindicatorsentrypoint"
  unidatapindicatorsentrypointdata <- read_sheet(unidatapindicatorsentrypointmlink,unidatapindicatorsentrypointsheetname)
  unidatapindicatorsentrypointdata
  #Print('Trying to find available data sources for the indicator ...')
  apizoneslist <- list()
  if (showDebugMessages){
    typeof(apizoneslist)
  }
  sp <- startperiod
  ep <- endperiod
  for (i in indicatorlist){
    if (showDebugMessages){
        print(i)
    }
    data1x <- unidatapindicatorsentrypointdata %>% filter(indicator==i)
    if (showDebugMessages){
      print("data1x:")
      print(data1x)
    }
    if (nrow(data1x)>0){
      for (i in 1:nrow(data1x)){
        wbl=data1x$wbooklink[i]
        if (showDebugMessages){
            print(wbl)
        }
        wbr=data1x$regionname[i]
        #print(wbr)
        data2x <- read_sheet(wbl, wbr)
        #print(data2x)
        data3x1 <- data2x %>% filter(indicator %in% indicatorlist, countrypartner %in% countrypartnerlist, beginperiod <= sp, endperiod >= sp)
        data3x2 <- data2x %>% filter(indicator %in% indicatorlist, countrypartner %in% countrypartnerlist, beginperiod <= ep, endperiod >= ep)
        data3x = rbind(data3x1,data3x2)
        #print(data3x)
        for (xapi in unique(as.list(data3x$apicode))) {
          # print(xapi)
          rnew=TRUE
          for (rec in apizoneslist) {
            # print("##")
            # print(rec)
            if (rec==xapi){
              rnew=FALSE
            }
          }
          # print (rnew)
          if (rnew){
            rec = xapi
            # print("$$")
            # print(rec)
            apizoneslist[[(length(apizoneslist) + 1)]] <- rec
          }
        }
      }
    }
  }
  # print("apizonelist")
  Print('The indicator is available from these sources:')
  print(apizoneslist)
  Print('Fetching the data. Please wait ...')
  dff <<- emptyunidatadataframe()
  for (p in unique(apizoneslist)){
    dff0 <<- emptyunidatadataframe()
    #print(p)
    p=str_trim(p)
    unidataapigdata <<- function(countrypartnerlist, indicatorlist, startperiod, endperiod) {
      # print("&&&&&&&&&&&&&&&&&&&")
      return (emptyunidatadataframe())
    }
    srcokfile <- paste(p,"_okfile.txt",sep="")
    srcapifile <- paste(p,"_definefunction.R",sep="")
    write("",srcokfile)
    # print("srcapifile:")
    # print(srcapifile)
    try(source(srcapifile)) #if successful redefines unidataapigdata and set srokfile content to "ok"
    print(unidataapigdata(countrypartnerlist, indicatorlist, startperiod, endperiod))
    srcok <- str_trim(read_file(srcokfile))
    # print("*****")
    # print(srcok)
    if (str_trim(srcok)=="ok"){
      # print("=====ok=====")
      # print(countrypartnerlist)
      # print(indicatorlist) 
      # print(startperiod)
      # print(endperiod)
      # print(unidataapigdata(countrypartnerlist, indicatorlist, startperiod, endperiod))
      dff0 <<- unidataapigdata(countrypartnerlist, indicatorlist, startperiod, endperiod)
      # print(dff0)
    }
    else
    {
      dff0 <<- emptyunidatadataframe()
    }
    # print("++++++++")
    # print(dff0)
    dff <<- rbind(dff, dff0)
  }
  return(dff)
}